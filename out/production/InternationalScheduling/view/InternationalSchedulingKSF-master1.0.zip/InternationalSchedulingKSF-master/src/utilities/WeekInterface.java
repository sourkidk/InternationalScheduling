package utilities;


import java.time.LocalDate;

@FunctionalInterface
public interface WeekInterface {
    public int sundayMath(LocalDate date);
}
