International Scheduling Application

This is an application for managing scheduling of business meetings for
companies with personnel located in multiple countries and states/provinces.

Keith S. Fletcher
009224586
BS Comp-Sci (5/1/22)
Karl Lloyd
828-423-3501 EST
kflet87@wgu.edu

Version 1.0.1
Released June 26, 2022

IntelliJ IDEA 2021.1.3 (Community Edition)
Java-JDK-17.0.1.3
JavaFX-SDK-18.0.1
mysql-connector-java-8.0.25

This is an application for managing scheduling of business meetings for companies with
personnel located in multiple countries and states/provinces.The database is populated
with states and provinces in the United Kingdom, Canada, and the United States.
The application enables user management of Customers and Appointments and handles time
zone conversion on the back end.  The system should detect the users time
zone and adjust the appointment times appropriately.  There are several useful reports as
well, that can be filtered for convenience.

Instructions:


